# MCGStarCraft リソースパック

## 対応バージョン
- **Minecraft 1.21.1** 用 (pack_format: 34)

## インストール方法

### 方法1: 直接配置
1. `MCGStarCraft-ResourcePack-1.0.0.zip` をダウンロード
2. Minecraftを起動
3. 設定 → リソースパック → "リソースパックフォルダーを開く"
4. ZIPファイルをそのフォルダにコピー
5. Minecraftでリソースパックを有効化

### 方法2: サーバー自動配信
サーバーの `server.properties` に以下を設定：
```properties
resource-pack=https://masafumiando.github.io/mcg-planets-docs/downloads/MCGStarCraft-ResourcePack-1.0.0.zip
resource-pack-sha1=<新しいSHA1ハッシュ値>
```

## トラブルシューティング

### "互換性がない" と表示される場合
1. Minecraft 1.21.1を使用しているか確認
2. ZIPファイルが破損していないか確認
3. pack.mcmetaのpack_formatが34になっているか確認

### リソースパックが認識されない場合
リソースパックの構造が以下のようになっているか確認：
```
MCGStarCraft-ResourcePack-1.0.0.zip
├── pack.mcmeta
├── pack.png
└── assets/
    ├── mcgstarcraft/
    │   ├── models/item/
    │   └── textures/item/
    └── minecraft/
        └── textures/misc/
```

## ビルド方法
```bash
cd mcg-starcraft-resourcepack
./scripts/build.sh
```

## バージョン履歴
- **v1.0.0** - 初回リリース (Minecraft 1.21.1対応)