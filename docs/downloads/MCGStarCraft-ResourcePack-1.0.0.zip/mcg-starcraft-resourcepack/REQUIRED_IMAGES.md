# MCGStarCraft リソースパック - 必要な画像ファイル一覧

このリソースパックには以下の画像ファイルが必要です。
各画像は16x16ピクセルのPNG形式で作成してください。

## ディレクトリ構造
```
mcg-starcraft-resourcepack/
├── pack.png (128x128px - パックアイコン)
└── assets/mcgstarcraft/textures/
    └── item/
        └── (以下の画像ファイル)
```

## 必要な画像ファイル

### 基本資源 (5個)
- [ ] `titanite_ore.png` - タイタナイト鉱石
- [ ] `conduit_crystals.png` - コンジットクリスタル
- [ ] `silicon_cell.png` - シリコンセル
- [ ] `thermoglue.png` - 熱接着剤（サーモグルー）
- [ ] `titanium_plates.png` - チタンプレート

### キャニスター類 (5個)
- [ ] `air_canister_empty.png` - 空の空気キャニスター
- [ ] `air_canister_oxygen.png` - 酸素入り空気キャニスター
- [ ] `air_canister_polluted.png` - 汚染空気キャニスター
- [ ] `air_canister_carbon.png` - 炭素空気キャニスター
- [ ] `fuel_canister.png` - 燃料キャニスター

### アップグレードキット - 空気タンク (4個)
- [ ] `air_tank_kit_1.png` - 空気タンクキット Tier 1
- [ ] `air_tank_kit_2.png` - 空気タンクキット Tier 2
- [ ] `air_tank_kit_3.png` - 空気タンクキット Tier 3
- [ ] `air_tank_kit_4.png` - 空気タンクキット Tier 4

### アップグレードキット - 燃料タンク (4個)
- [ ] `fuel_tank_kit_1.png` - 燃料タンクキット Tier 1
- [ ] `fuel_tank_kit_2.png` - 燃料タンクキット Tier 2
- [ ] `fuel_tank_kit_3.png` - 燃料タンクキット Tier 3
- [ ] `fuel_tank_kit_4.png` - 燃料タンクキット Tier 4

### アップグレードキット - 放射線防護 (4個)
- [ ] `radiation_kit_1.png` - 放射線防護キット Tier 1
- [ ] `radiation_kit_2.png` - 放射線防護キット Tier 2
- [ ] `radiation_kit_3.png` - 放射線防護キット Tier 3
- [ ] `radiation_kit_4.png` - 放射線防護キット Tier 4

### アップグレードキット - 温度耐性 (4個)
- [ ] `temperature_kit_1.png` - 温度耐性キット Tier 1
- [ ] `temperature_kit_2.png` - 温度耐性キット Tier 2
- [ ] `temperature_kit_3.png` - 温度耐性キット Tier 3
- [ ] `temperature_kit_4.png` - 温度耐性キット Tier 4

### 宇宙服パーツ (4個)
- [ ] `space_helm.png` - 宇宙ヘルメット
- [ ] `space_vest.png` - 宇宙ベスト
- [ ] `space_pants.png` - 宇宙パンツ
- [ ] `space_boots.png` - 宇宙ブーツ

### パックアイコン (1個)
- [ ] `pack.png` - リソースパックのアイコン (128x128px)

## 合計: 31個の画像ファイル

## 現在の状況

### 配置済み（サンプルから流用）

#### mythicmetals-emissiveから：
- ✅ `titanite_ore.png` - adamantite_ore から流用
- ✅ `conduit_crystals.png` - aquarium_ore から流用
- ✅ `silicon_cell.png` - kyber_ore から流用
- ✅ `titanium_plates.png` - platinum_ore から流用
- ✅ `fuel_canister.png` - starrite_ore から流用

#### spacesuit-v2から：
- ✅ 宇宙服アーマーテクスチャ - armor/spacesuit_layer_1,2.png
- ✅ HUDオーバーレイ - pumpkinblur.png

#### Norzeteus Space 1.21から（新規追加）：
- ✅ `thermoglue.png` - honey_bottle から流用
- ✅ `air_canister_empty.png` - potion から流用
- ✅ `air_canister_oxygen.png` - experience_bottle から流用
- ✅ `air_canister_polluted.png` - splash_potion から流用
- ✅ `air_canister_carbon.png` - lingering_potion から流用
- ✅ `space_helm.png` - iron_helmet から流用
- ✅ `space_vest.png` - chainmail_chestplate から流用
- ✅ `space_pants.png` - iron_leggings から流用
- ✅ `space_boots.png` - iron_boots から流用
- ✅ `air_tank_kit_1~4.png` - iron/gold/diamond/netherite_ingot から流用
- ✅ `fuel_tank_kit_1~4.png` - iron/gold/diamond/netherite_ingot から流用
- ✅ `radiation_kit_1~4.png` - iron/gold/diamond/netherite_ingot から流用
- ✅ `temperature_kit_1~4.png` - iron/gold/diamond/netherite_ingot から流用
- ✅ `pack.png` - Norzeteus Space のパックアイコンから流用
- ✅ 高解像度HUDオーバーレイ - pumpkinblur_hd.png として追加

### 全31個の画像ファイル配置完了！
すべての必要な画像が配置されました。アップグレードキットは暫定的に各Tierの素材（鉄、金、ダイヤ、ネザライト）のインゴットテクスチャを使用しています。

## 画像作成のガイドライン

### 推奨スタイル
- Minecraftの標準テクスチャスタイルに準拠
- ピクセルアート形式
- 明瞭で識別しやすいデザイン

### 色の提案
- **タイタナイト**: 灰色/銀色系
- **コンジット**: 青緑/エメラルド系
- **シリコン**: 黒/ダークグレー系
- **キャニスター**: 金属的な銀色にカラーアクセント
- **アップグレードキット**: Tierごとに色を変更（1:鉄、2:金、3:ダイヤ、4:ネザライト風）
- **宇宙服**: 白/グレーベースにオレンジのアクセント

### ファイル配置
画像ファイルは以下の場所に配置してください：
```
mcg-starcraft-resourcepack/assets/mcgstarcraft/textures/item/
```

パックアイコンは以下の場所に配置：
```
mcg-starcraft-resourcepack/pack.png
```